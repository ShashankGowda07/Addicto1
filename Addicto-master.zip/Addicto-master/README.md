# 🔥 Addicto App

An App to Challenge your addiction. It includes some tools that will help you with your addiction.

Star⭐ the repo if you like what you see😉.

## ✨ Features :
- Countdown Timer .
- Top recommended books about addiction.
- Visit the original website of the book with Flutter WebView.
- A quiz to test addiction.
- Beautiful UI.

## 📸 Screenshots :

<img src="screenshots/image 1.png" width="300"> <img src="screenshots/image 2.png" width="300"> <img src="screenshots/image 3.png" width="300">
<img src="screenshots/image 4.png" width="300"> <img src="screenshots/image 5.png" width="300"> <img src="screenshots/image 6.png" width="300"> <img src="screenshots/image 7.png" width="300">

**=> The 1st Onboarding img is from (<a href="https://storyset.com/people">People illustrations by Storyset</a>)**

**=> The 2nd Onboarding img is from (<a href="https://storyset.com/group">Group illustrations by Storyset</a>)**

**=> The 3rd Onboarding img is from (<a href="https://storyset.com/people">People illustrations by Storyset</a>)**

**=> The img used in the drawer is from [Robert Nickson](https://www.pexels.com/photo/brown-mountains-2559941/)**
