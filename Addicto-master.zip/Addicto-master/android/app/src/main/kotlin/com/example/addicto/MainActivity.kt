package com.example.addicto

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
