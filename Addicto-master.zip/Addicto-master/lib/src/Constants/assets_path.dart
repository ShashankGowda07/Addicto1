class MyAssets {
  static const String onboradingone = 'assets/icons/addiction.png';
  static const String onboradingtwo = 'assets/icons/books.png';
  static const String onboradingthree = 'assets/icons/quotation.png';
  static const String drawerimage = 'assets/images/nature.jpg';
  static const String libraryimage = 'assets/images/books.jpg';
  static const String ponbooks = 'assets/json/pon_books.json';
  static const String drugbooks = 'assets/json/drug_books.json';
  static const String alcoholbooks = 'assets/json/alcohol_books.json';
  static const String internetbooks = 'assets/json/internet_books.json';
}
