const String onboarding = '/';
const String homescreen = '/home_screen';
const String bookscreen = '/book_screen';
const String testscreen = '/test_screen';
const String testwelcomescreen = '/twelcome_screen';
const String quotescreen = '/quote_screen';
const String webpagescreen = '/webpage_screen';
