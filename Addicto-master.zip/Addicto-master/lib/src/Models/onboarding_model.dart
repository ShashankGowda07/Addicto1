class OnBoardingModel {
  final String img, title, content;

  const OnBoardingModel(
      {required this.img, required this.title, required this.content});
}
