class QuoteModel {
  String quote;
  String author;
  QuoteModel({
    required this.quote,
    required this.author,
  });
}
